package com.example.mobileapplicationcw2_w2081487

import androidx.room.Entity
import androidx.room.PrimaryKey

//Room entity which i have represented with meals table in the local SQL
//is for meal data including all the meta data
//is used for storagge and to get o the meal data inside the app
@Entity(tableName = "meals")
data class Meal(
    @PrimaryKey(autoGenerate = true) val id: Int =0,
    //some String is nullable which means that it can be empty
    val name:String,
    val category: String,
    val area:String,
    val instructions:String,
    val mealThumb: String?,
    val tags: String?,
    val youtube:String?,

    val ingredient1: String?,
    val ingredient2: String?,
    val ingredient3: String?,
    val ingredient4: String?,
    val ingredient5: String?,
    val ingredient6: String?,
    val ingredient7:String?,
    val ingredient8:String?,
    val ingredient9: String?,
    val ingredient10:String?,
    val ingredient11: String?,
    val ingredient12: String?,
    val ingredient13: String?,
    val ingredient14: String?,
    val ingredient15: String?,
    val ingredient16: String?,
    val ingredient17:String?,
    val ingredient18:String?,
    val ingredient19: String?,
    val ingredient20:String?,

    val measure1:String?,
    val measure2:String?,
    val measure3:String?,
    val measure4:String?,
    val measure5:String?,
    val measure6:String?,
    val measure7:String?,
    val measure8: String?,
    val measure9: String?,
    val measure10: String?,
    val measure11:String?,
    val measure12:String?,
    val measure13:String?,
    val measure14:String?,
    val measure15:String?,
    val measure16:String?,
    val measure17:String?,
    val measure18: String?,
    val measure19: String?,
    val measure20: String?
)