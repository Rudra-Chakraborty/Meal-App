package com.example.mobileapplicationcw2_w2081487
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

//this function is used for saving
fun fetchMealsObjects(ingredient: String): List<Meal> {
   //API request to filter meals by ingrediet edited the
    // manifest file followed the tutorial
    val url = URL("https://www.themealdb.com/api/json/v1/1/filter.php?i=$ingredient")
    // this will open http connection and read reasponse
    //concept of this learened in Client server module
    //buffred reader is used to wrap it for reading effeciecy and inputStrem to get the
    //raw response
    val connection =url.openConnection() as HttpURLConnection
    val response =connection.inputStream.bufferedReader().readText()
    // converts the string ino the json object
    val json =JSONObject(response)
    //it extracts out the meal array ,returns the empty list if is null
    val mealsArray = json.optJSONArray("meals") ?: return emptyList()
    // list is used to store the mael object
    val list =mutableListOf<Meal>()

  // the for look i have used  that loops through each meal retuned fromAPI
    for (i in 0 until mealsArray.length()) {

       //extracts the id to fetch the full detail
        val id = mealsArray.getJSONObject(i).optString("idMeal")

      // second api is used to retrive detasls of meal using id
        val detailUrl = URL("https://www.themealdb.com/api/json/v1/1/lookup.php?i=$id")
        val detailConn = detailUrl.openConnection() as HttpURLConnection
        val detailResponse = detailConn.inputStream.bufferedReader().readText()
       // pare of json response
        val detailJson = JSONObject(detailResponse)
        val mealObj = detailJson.getJSONArray("meals").getJSONObject(0)
       //maps json fields to meal object including the ingredients and measures
        val meal = Meal(
            name = mealObj.optString("strMeal"),
            category = mealObj.optString("strCategory"),
            area = mealObj.optString("strArea"),
            instructions = mealObj.optString("strInstructions"),
            mealThumb = mealObj.optString("strMealThumb"),
            tags = mealObj.optString("strTags"),
            youtube = mealObj.optString("strYoutube"),
            //ingrdients

            ingredient1 =mealObj.optString("strIngredient1"),
            ingredient2 =mealObj.optString("strIngredient2"),
            ingredient3 =mealObj.optString("strIngredient3"),
            ingredient4 = mealObj.optString("strIngredient4"),
            ingredient5= mealObj.optString("strIngredient5"),
            ingredient6 = mealObj.optString("strIngredient6"),
            ingredient7=mealObj.optString("strIngredient7"),
            ingredient8= mealObj.optString("strIngredient8"),
            ingredient9= mealObj.optString("strIngredient9"),
            ingredient10= mealObj.optString("strIngredient10"),
            ingredient11= mealObj.optString("strIngredient11"),
            ingredient12= mealObj.optString("strIngredient12"),
            ingredient13= mealObj.optString("strIngredient13"),
            ingredient14= mealObj.optString("strIngredient14"),
            ingredient15= mealObj.optString("strIngredient15"),
            ingredient16= mealObj.optString("strIngredient16"),
            ingredient17= mealObj.optString("strIngredient17"),
            ingredient18= mealObj.optString("strIngredient18"),
            ingredient19= mealObj.optString("strIngredient19"),
            ingredient20= mealObj.optString("strIngredient20"),
            // measures
            measure1=mealObj.optString("strMeasure1"),
            measure2 =mealObj.optString("strMeasure2"),
            measure3 =mealObj.optString("strMeasure3"),
            measure4 =mealObj.optString("strMeasure4"),
            measure5= mealObj.optString("strMeasure5"),
            measure6= mealObj.optString("strMeasure6"),
            measure7=mealObj.optString("strMeasure7"),
            measure8=mealObj.optString("strMeasure8"),
            measure9=mealObj.optString("strMeasure9"),
            measure10=mealObj.optString("strMeasure10"),
            measure11=mealObj.optString("strMeasure11"),
            measure12= mealObj.optString("strMeasure12"),
            measure13 = mealObj.optString("strMeasure13"),
            measure14 =mealObj.optString("strMeasure14"),
            measure15 =mealObj.optString("strMeasure15"),
            measure16 =mealObj.optString("strMeasure16"),
            measure17 =mealObj.optString("strMeasure17"),
            measure18 =mealObj.optString("strMeasure18"),
            measure19 =mealObj.optString("strMeasure19"),
            measure20 = mealObj.optString("strMeasure20")
        )
        list.add(meal)
    }
    return list
}