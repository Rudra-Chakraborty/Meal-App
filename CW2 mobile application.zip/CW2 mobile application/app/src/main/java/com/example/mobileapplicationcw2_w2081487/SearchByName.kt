package com.example.mobileapplicationcw2_w2081487

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
//fetching the meals by name function
fun fetchMealsByName(query: String): List<String> {

    val url = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=$query")
    val connection = url.openConnection() as HttpURLConnection

    connection.requestMethod = "GET"
    connection.connect()
    val response =connection.inputStream.bufferedReader().readText()
    val json =JSONObject(response)
    val mealsArray =json.optJSONArray("meals") ?: return emptyList()
    val list =mutableListOf<String>()

    for (i in 0 until mealsArray.length()) {

        val meal =mealsArray.getJSONObject(i)
        val name= meal.optString("strMeal")

       //it will ignoreCase
        if (name.contains(query, ignoreCase= true)) {
            list.add(name)
        }
    }
    return list
}