package com.example.mobileapplicationcw2_w2081487
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.net.URL
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign

//composable screen that allows the user to search meals stored in the database
//based on name or ingrediet and displays resalts including images
//part of task 5 and 6
@Composable
fun SearchByMeals(dao: MealDao) {
    //to stores user input query
    var query by  rememberSaveable { mutableStateOf("") }
    //stores search results retrieved from the database
    var results by  rememberSaveable { mutableStateOf(listOf<Meal>()) }
    //coroutine scope for launching background works
    val scope = rememberCoroutineScope( )

    //this the UI design
    Column(
        modifier = Modifier
            .fillMaxSize( )
            .background(Color(0xFF7CC1F8))
            .padding(24.dp),
        //alings it center with some spacing
        verticalArrangement =Arrangement.Center,
        horizontalAlignment=Alignment.CenterHorizontally
    ) {
        Text(
            text = "Search By Meals or Ingredient",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(60.dp))

        // enter search query so that it can be search
        TextField(
            value =query,
            onValueChange ={ query =it },
            label ={ Text("Search meals or ingredients") },
            modifier =Modifier.fillMaxWidth(0.9f)
        )

        Spacer(modifier = Modifier.height(20.dp))


        Button(
            onClick ={
                scope.launch{

                    //substring matching
                    results = dao.searchMeals(query)
                }
            },
            modifier = Modifier.fillMaxWidth(0.9f),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFF59D))
        ) {
            Text("Search", fontSize = 18.sp, color = Color.Black)
        }

        Spacer(modifier = Modifier.height(20.dp))

        //https://www.youtube.com/watch?v=XfYlRn_Jy1g&t=240s
        //lazy column i have used so that it can be scrolled
        if(query.isNotBlank()&& results.isEmpty()) {
            Text("No meals found/please enter a meal")
        }
        LazyColumn {
            items(results) { meal ->
                //thos will hold dowloaded image
                var bitmap by remember { mutableStateOf<Bitmap?>(null) }

                val scope = rememberCoroutineScope()

                // load image in background
                LaunchedEffect(meal.mealThumb) {
                    bitmap = withContext(Dispatchers.IO) {
                        //it will fetch image url
                        loadImageFromUrl(meal.mealThumb)
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp)
                ) {
                    Text(
                        text = meal.name,
                        fontSize = 18.sp
                    )
                    //it will display the image if available
                    bitmap?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = meal.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }
}

//loads an image from a url and converts it into a bitmap.
//runs on a backgrouond thread to avoid blocking the ui.
fun loadImageFromUrl(url: String?): Bitmap? {
    return try {
        if (url.isNullOrEmpty()) return null
        val inputStream = URL(url).openStream()
        BitmapFactory.decodeStream(inputStream)
    } catch (e: Exception) {
        null
    }
}