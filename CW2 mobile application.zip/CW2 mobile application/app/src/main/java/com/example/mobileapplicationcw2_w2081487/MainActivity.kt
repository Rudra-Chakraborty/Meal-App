package com.example.mobileapplicationcw2_w2081487

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.room.Room
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // room database instance
        //https://www.youtube.com/watch?v=CcaCpRCACzU
        //leaned the concept of room , dao and more
        val db = Room.databaseBuilder(
            this,
            MealDatabase::class.java,
            "meal_db"
        ).build()
        //database object retrival
        val dao = db.mealDao()
        //GUI for the applicotion
        setContent {
            MealAppMenuScreen(dao)
        }
    }
}
//this is composable represetts the main page of this app
//this function will allow to move from one page to the other
//also i added access to database through the DAO
@Composable
fun MealAppMenuScreen(dao: MealDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    //the screen is savable so that change in oriantatuon will not effect will show the curret page
    var screen by  rememberSaveable { mutableStateOf("menu") }
    // this for android back button to return to main page
    //ide taken from here https://developer.android.com/develop/ui/compose/libraries#handling_the_system_back_button
    BackHandler(enabled = screen!= "menu") {
        screen="menu"
    }

    if (screen=="menu") {
      // the layout of the buttons that is displayed
        Column(
            modifier =  Modifier
                .fillMaxSize()
                .background(Color(0xFF7CC1F8))
                .padding(20.dp),
            verticalArrangement =Arrangement.Center,
            horizontalAlignment=Alignment.CenterHorizontally
        ) {
            Text(
                text = "Welcome to Meal App",
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(60.dp))


            // creted the button this is task 1
            Button(
                onClick ={
                    // thiss Launches a coroutine on a background thread (IO dispatcher)
                     // to perform database/networnk operations without blocking thee UI
                    scope.launch(Dispatchers.IO) {
                        //hard coded few meals
                        val meal1 = Meal(
                            name ="Sweet and Sour Pork",
                            category="Pork",
                            area = "Chinese",
                            instructions ="Cook pork and mix sauce.",
                            mealThumb =null,
                            tags ="Sweet",
                            youtube = null,

                            ingredient1 ="Pork",
                            ingredient2= "Egg",
                            ingredient3= "Water",
                            ingredient4="Salt",
                            ingredient5= "Sugar",
                            ingredient6 ="Soy Sauce",
                            ingredient7 ="Starch",
                            ingredient8 ="Tomato",
                            ingredient9 ="Vinegar",
                            ingredient10 = "Coriander",

                            ingredient11 = null,
                            ingredient12 = null,
                            ingredient13 = null,
                            ingredient14 = null,
                            ingredient15 = null,
                            ingredient16 = null,
                            ingredient17 = null,
                            ingredient18 = null,
                            ingredient19 = null,
                            ingredient20 = null,

                            measure1 = "200g",
                            measure2 = "1",
                            measure3 = "Dash",
                            measure4 = "1/2 tsp",
                            measure5 = "1 tsp",
                            measure6 = "10g",
                            measure7 = "10g",
                            measure8 = "30g",
                            measure9 = "10g",
                            measure10 = "Dash",

                            measure11 = null,
                            measure12 = null,
                            measure13 = null,
                            measure14 = null,
                            measure15 = null,
                            measure16 = null,
                            measure17 = null,
                            measure18 = null,
                            measure19 = null,
                            measure20 = null
                        )

                        val meal2 = Meal(
                            name ="Chicken Marengo",
                            category ="Chicken",
                            area = "French",
                            instructions ="Cook chicken with mushrooms.",
                            mealThumb =null,
                            tags=null,
                            youtube=null,

                            ingredient1="Chicken",
                            ingredient2="Mushrooms",
                            ingredient3="Olive Oil",
                            ingredient4="Passata",
                            ingredient5="Stock Cube",
                            ingredient6= "Olives",
                            ingredient7= "Parsley",

                            ingredient8 = null,
                            ingredient9 = null,
                            ingredient10 = null,

                            ingredient11 = null,
                            ingredient12 = null,
                            ingredient13 =null,
                            ingredient14= null,
                            ingredient15= null,
                            ingredient16= null,
                            ingredient17 =null,
                            ingredient18 =null,
                            ingredient19 = null,
                            ingredient20 = null,

                            measure1= "4",
                            measure2= "300g",
                            measure3="1 tbsp",
                            measure4 ="500g",
                            measure5 = "1",
                            measure6 ="100g",
                            measure7 ="Chopped",

                            measure8=null,
                            measure9=null,
                            measure10 = null,
                            measure11 = null,
                            measure12=null,
                            measure13=null,
                            measure14 =null,
                            measure15 = null,
                            measure16= null,
                            measure17= null,
                            measure18= null,
                            measure19= null,
                            measure20= null
                        )

                        val meal3 = Meal(
                            name = "Leblebi Soup",
                            category = "Vegetarian",
                            area = "Tunisian",
                            instructions = "Simmer chickpeas with spices.",
                            mealThumb = null,
                            tags = "Soup",
                            youtube = null,

                            ingredient1="Chickpeas",
                            ingredient2="Onion",
                            ingredient3 ="Garlic",
                            ingredient4 ="Vegetable Stock",
                            ingredient5 = "Cumin",
                            ingredient6 ="Harissa",
                            ingredient7 ="Salt",
                            ingredient8 ="Pepper",
                            ingredient9 ="Olive Oil",
                            ingredient10 ="Lime",

                            ingredient11=null,
                            ingredient12= null,
                            ingredient13 = null,
                            ingredient14= null,
                            ingredient15= null,
                            ingredient16 = null,
                            ingredient17=null,
                            ingredient18 = null,
                            ingredient19= null,
                            ingredient20= null,

                            measure1="250g",
                            measure2= "1",
                            measure3= "5 cloves",
                            measure4 = "1.5L",
                            measure5="1 tsp",
                            measure6="1 tsp",
                            measure7= "1/2 tsp",
                            measure8 ="Pinch",
                            measure9 = "2 tbsp",
                            measure10= "1/2",

                            measure11=null,
                            measure12=null,
                            measure13=null,
                            measure14= null,
                            measure15 =null,
                            measure16 =null,
                            measure17 =null,
                            measure18 =null,
                            measure19 =null,
                            measure20 =null
                        )
                        //inserted all

                        dao.insertAll(meal1,meal2,meal3)
                        //to show tat is saveded to database
                        withContext(Dispatchers.Main) {
                            Toast.makeText(
                                context,
                                "meals added to database",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor =Color(0xFFFFF59D), // light yellow better to see
                    contentColor =Color.Black
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Add Meals to DB",fontSize = 20.sp)
            }

            // search for meals by ingrediant button
            Button(
                onClick ={ screen = "search"},
                colors =ButtonDefaults.buttonColors(
                    containerColor =Color(0xFFFFF59D),
                    contentColor =Color.Black
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ){
                Text("Search for Meals By Ingredient", fontSize = 20.sp)
            }

            //Searching for meal it saves to database i have implemented this for
            //task 5
            Button(
                onClick = { screen = "search2" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFF59D),
                    contentColor = Color.Black
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical =8.dp)
            ){
                Text("Search for Meals", fontSize = 20.sp)
            }
            //button for task 7 which is the extended taskk
            Button(
                onClick = { screen = "search3" },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFF59D),
                    contentColor = Color.Black
                ),
                modifier =Modifier
                    .fillMaxWidth()
                    .padding(vertical =8.dp)
            ) {
                Text("Search for Meals By Name", fontSize = 20.sp)
            }


        }
    }

// all the screens
    if (screen == "search"){
        SearchMealScreen(dao)
    }

    if (screen == "search2"){
        SearchByMeals(dao)
    }
    if (screen == "search3"){
        WebSearchScreen()
    }
}