package com.example.mobileapplicationcw2_w2081487

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

//room database that holds the meal
@Database(entities = [Meal::class], version = 1)
abstract class MealDatabase: RoomDatabase() {
    //this willl provide access to mealdao for the queries and operation
    abstract fun mealDao(): MealDao
}