package com.example.mobileapplicationcw2_w2081487

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SearchMealScreen(dao: MealDao) {
    val context = LocalContext.current
     //all the variables to show the result and sav the rusult
    var ingredient by rememberSaveable{ mutableStateOf("")}
    var resultText by rememberSaveable{ mutableStateOf("")}
    var mealsList by rememberSaveable{ mutableStateOf(listOf<Meal>())}

    val scope = rememberCoroutineScope()
     //the layout i have learned from the following resources
    //https://developer.android.com/develop/ui/compose/layouts/flow
    //https://www.youtube.com/watch?v=xBKQ01LRuuE&t=13748s

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF7CC1F8))
            .padding(20.dp),

        horizontalAlignment = Alignment.CenterHorizontally
    ){
        Text(
            text ="Search for Meals by Ingredient",
            fontSize = 30.sp,
            fontWeight =FontWeight.Bold,
            modifier =Modifier.fillMaxWidth(),
            textAlign =TextAlign.Center
        )

        Spacer(modifier = Modifier.height(60.dp))


        TextField(
            value =ingredient,
            onValueChange ={ ingredient = it },
            label = { Text("Enter Ingredient") },
            modifier =Modifier.fillMaxWidth(0.9f)
        )
        Spacer(modifier = Modifier.height(20.dp))

        //retrieve button
        Button(
            onClick ={
                scope.launch(Dispatchers.IO) {
                    val result = fetchMealsByIngredient(ingredient)
                    val meals = fetchMealsObjects(ingredient)

                    withContext(Dispatchers.Main) {
                        resultText = result
                        mealsList = meals ?: emptyList()
                    }
                }
            },
            modifier =Modifier.fillMaxWidth(0.9f)
        ) {
            Text("Retrieve Meals", fontSize = 16.sp)
        }

        Spacer(modifier =Modifier.height(12.dp))

        // button for saving the meal to database
        Button(
            onClick ={
                scope.launch(Dispatchers.IO) {
                    //to insert all in the database
                    dao.insertAll(*mealsList.toTypedArray())
                    //this will show a message when is saved
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            "Meals saved to database",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

            },
            modifier=Modifier.fillMaxWidth(0.9f),
            //the layout used here is when the mealList not empty use can store
            //the data in the database
            enabled=mealsList.isNotEmpty()
        ) {
            Text("Save Meals to Database")
        }

        Spacer(modifier = Modifier.height(20.dp))

      //if is empty
        Column(
            modifier =  Modifier
                .fillMaxWidth()
                .weight(1f)// it will taken the remmaining
                //space i used it for good layout from kotlin website
                //https://developer.android.com/develop/ui/compose/layouts/flow
                .background(Color(0xFFF5F4EF))
                .verticalScroll(rememberScrollState())
        ) {
            if (mealsList.isEmpty()) {
                Text("No meals found or no input yet")
            } else {
                Text(text = resultText)
            }
        }
    }
}