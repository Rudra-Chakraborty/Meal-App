package com.example.mobileapplicationcw2_w2081487

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.*
import androidx.compose.foundation.layout.*

import androidx.compose.material3.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

//search the name of meal task 7
@Composable
fun WebSearchScreen() {
     //to save quary and results
    var query by rememberSaveable{mutableStateOf("") }
    var results by rememberSaveable{ mutableStateOf(listOf<String>()) }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF7CC1F8))
            .padding(40.dp),
        verticalArrangement =Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Search for Meals By Name",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(60.dp))
        TextField(
            value =query,
            onValueChange={query = it },
            label={ Text("Search Meal Name") }
        )
        Spacer(modifier =Modifier.height(20.dp))

        Button(
            onClick ={
                scope.launch(Dispatchers.IO) {
                    //it vetches meal by name  store in data
                    val data = fetchMealsByName(query)
                    withContext(Dispatchers.Main) {
                       // result is shown
                        results = data
                    }
                }
            }
        ) {
            Text("Search")
        }

        Spacer(modifier =Modifier.height(20.dp))

        Column(
            modifier= Modifier.verticalScroll(rememberScrollState())
        ) {
            if (results.isEmpty()) {
                Text("No meals found or meal not entered")
            } else {
                results.forEach {
                    Text(it)
                }
            }
        }
    }
}