package com.example.mobileapplicationcw2_w2081487

import androidx.room.*

//dao for meal database
//all the database operation itcludes
@Dao
interface MealDao {
    //it allows to insert multiple meals into the databese
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(vararg meals:Meal)
    //gets all the meals and stres in in databasse
    @Query("SELECT * FROM meals")
    suspend fun getAllMeals( ): List<Meal>

// learned in other module Database System
    //prevouse knowledge applied from one of he tutorial
    @Query("""
    SELECT * FROM meals
    WHERE LOWER(name) LIKE '%' || LOWER(:query) ||'%'
    OR LOWER(ingredient1) LIKE '%' || LOWER(:query) ||'%'
    OR LOWER(ingredient2) LIKE '%' ||LOWER(:query) || '%'
    OR LOWER(ingredient3) LIKE '%' || LOWER(:query) || '%'
    OR LOWER(ingredient4) LIKE '%'|| LOWER(:query) || '%'
    OR LOWER(ingredient5) LIKE '%'|| LOWER(:query) || '%'
    OR LOWER(ingredient6) LIKE '%'|| LOWER(:query) || '%'
    OR LOWER(ingredient7) LIKE '%'|| LOWER(:query) || '%'
    OR LOWER(ingredient8) LIKE '%' || LOWER(:query) || '%'
    OR LOWER(ingredient9) LIKE '%' || LOWER(:query) || '%'
    OR LOWER(ingredient10) LIKE '%' || LOWER(:query) || '%'
    """)
    suspend fun searchMeals(query: String): List<Meal>





}