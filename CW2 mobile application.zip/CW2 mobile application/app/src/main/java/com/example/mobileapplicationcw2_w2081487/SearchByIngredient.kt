package com.example.mobileapplicationcw2_w2081487

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

//this function is used to display task 3
fun fetchMealsByIngredient(ingredient: String): String {

    val url = URL("https://www.themealdb.com/api/json/v1/1/filter.php?i=$ingredient")
    val connection = url.openConnection() as HttpURLConnection
    //to get the request learned from client server module
    connection.requestMethod = "GET"
    connection.connect()

    val response =connection.inputStream.bufferedReader().readText()
    val json= JSONObject(response)
    val mealsArray= json.optJSONArray("meals") ?: return "No meals found"
    val output= StringBuilder()

    for (i in 0 until mealsArray.length()) {

        val mealObj = mealsArray.getJSONObject(i)
        val id = mealObj.optString("idMeal")

        // second API call for full details by id
        val detailUrl =URL("https://www.themealdb.com/api/json/v1/1/lookup.php?i=$id")
        val detailConn = detailUrl.openConnection() as HttpURLConnection
        detailConn.requestMethod = "GET"
        detailConn.connect()

        val detailResponse =detailConn.inputStream.bufferedReader().readText()
        val detailJson =JSONObject(detailResponse)

        val meal =detailJson.getJSONArray("meals").getJSONObject(0)

        // shows the information in the screen
        output.append("\"Meal\":\"${meal.optString("strMeal")}\",\n")
        output.append("\"DrinkAlternate\":\"${meal.optString("strDrinkAlternate")}\",\n")
        output.append("\"Category\":\"${meal.optString("strCategory")}\",\n")
        output.append("\"Area\":\"${meal.optString("strArea")}\",\n")
        output.append("\"Instructions\":\"${meal.optString("strInstructions")}\",\n")
        output.append("\"Tags\":\"${meal.optString("strTags")}\",\n")
        output.append("\"Youtube\":\"${meal.optString("strYoutube")}\",\n")

        // from tutorial 10
        for (j in 1..20) {
            val ing = meal.optString("strIngredient$j")
            if (ing.isNullOrBlank()) break
            output.append("\"Ingredient$j\":\"$ing\",\n")
        }

        // from tutorial 1
        for (j in 1..20) {
            val meas = meal.optString("strMeasure$j")
            if (meas.isNullOrBlank()) break
            output.append("\"Measure$j\":\"$meas\",\n")
        }
         //used this to separate the meals
        output.append("\n-----------------------------\n\n")
    }
    return output.toString()
}